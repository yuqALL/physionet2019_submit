# -*- coding: utf-8 -*-

import numpy as np
import extractFeatures as ef
import os

x_mean = np.array([
    83.8996, 97.0520, 36.8055, 126.2240, 86.2907,
    66.2070, 18.7280, 33.7373, -3.1923, 22.5352,
    0.4597, 7.3889, 39.5049, 96.8883, 103.4265,
    22.4952, 87.5214, 7.7210, 106.1982, 1.5961,
    0.6943, 131.5327, 2.0262, 2.0509, 3.5130,
    4.0541, 1.3423, 5.2734, 32.1134, 10.5383,
    38.9974, 10.5585, 286.5404, 198.6777,
    60.8711, 0.5435, 0.0615, 0.0727, -59.6769, 28.4551])

x_std = np.array([
    17.6494, 3.0163, 0.6895, 24.2988, 16.6459,
    14.0771, 4.7035, 11.0158, 3.7845, 3.1567,
    6.2684, 0.0710, 9.1087, 3.3971, 430.3638,
    19.0690, 81.7152, 2.3992, 4.9761, 2.0648,
    1.9926, 45.4816, 1.6008, 0.3793, 1.3092,
    0.5844, 2.5511, 20.4142, 6.4362, 2.2302,
    29.8928, 7.0606, 137.3886, 96.8997,
    16.1887, 0.4981, 0.7968, 0.8029, 160.8846, 29.5367])

featureName = np.array(['HR', 'O2Sat', 'Temp', 'SBP', 'MAP', 'DBP', 'Resp', 'EtCO2', 'BaseExcess', 'HCO3', 'FiO2', 'pH',
                        'PaCO2', 'SaO2', 'AST', 'BUN', 'Alkalinephos', 'Calcium', 'Chloride', 'Creatinine',
                        'Bilirubin_direct', 'Glucose', 'Lactate', 'Magnesium',
                        'Phosphate', 'Potassium', 'Bilirubin_total', 'TroponinI', 'Hct', 'Hgb', 'PTT', 'WBC',
                        'Fibrinogen',
                        'Platelets', 'Age', 'Gender', 'Unit1', 'Unit2', 'HospAdmTime', 'ICULOS'])


# 读取数据记录文件
def readData(filename):
    with open(filename, 'r') as f:
        header = f.readline().strip()
        column_names = header.split('|')
        values = np.loadtxt(f, delimiter='|')
    return values


# 得到训练数据分类结果
def getResult(data):
    return data[0][:, -1]


# 输入所有数据特征
def getOriginFeature(data):
    feature = data[0][:, :-1]
    return feature


# 输入所有数据特征
def getFeature(data):
    feature = data

    h, w = feature.shape

    for j in range(w):
        for i in range(h):
            if np.isnan(feature[i, j]):
                feature[i, j] = searchNearValue(i, feature[:, j], h)
                if np.isnan(feature[i, j]):
                    feature[i, j] = x_mean[j]


    exlen = 34
    # norm = ef.data_norm(feature)
    res = ef.residualValue(feature[:, :exlen])

    rMax = ef.listMax(res)
    rMin = ef.listMin(res)
    rMean = ef.listMean(res)
    rSum = ef.listSum(res)
    rStat = np.hstack((rMax, rMin, rMean, rSum))
    # print(rMax.shape)

    grad1 = ef.featureGrad(res)
    grad12 = ef.featureGrad_12(res)

    grad = np.hstack((grad1, grad12))


    hess1 = ef.featureGrad(grad1)


    mutation = ef.mutationFactor(res)

    mutation12h = ef.mutationFactor_12h(res)
    # mutation_rotate = ef.mutationFactor_12_rotate(feature)
    mu = np.hstack((mutation,  mutation12h))


    # print(np.array(mutation12).shape)
    fSum = ef.featureSum(res)
    fSum8 = ef.featureSum_8h(res)
    fMax = ef.featureMax(res)
    fMin = ef.featureMin(res)
    fMean = ef.featureMean(res)
    fVar = ef.featureVar(res)
    stat = np.hstack((fSum, fSum8, fMax, fMin, fMean, fVar))
    # fMedian = ef.featureMedian(feature[:, :exlen])
    # print(np.array(fSum).shape)
    # print(np.array(fSum8).shape)
    # print(np.array(fMax).shape)
    # print(np.array(fMin).shape)
    # print(np.array(fMean).shape)

    # fCov = ef.covFilter(feature[:, :exlen])
    # # kernel = np.array([[1, 2, 3, 2, 1], [2, 4, 6, 4, 2], [4, 8, 12, 8, 4], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]])
    # norm = ef.feature_normalization(feature[:, :exlen])
    # kernel = np.array([[1, 2, 1], [2, 4, 2], [1, 2, 1]])
    # fCov2 = ef.Filter2d(norm, kernel / np.sum(kernel))
    # laplace_kernel = np.array([[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]])
    # fCov_laplace = ef.Filter2d(norm, laplace_kernel)
    # cov = np.hstack((fCov, fCov2, fCov_laplace))

    fEnergy = ef.abs_energy(res)
    gAbsSC = ef.absolute_sum(grad1)
    # hAbsSC = ef.absolute_sum(hess1)
    rAboveZero = ef.count_above_zero(res)
    rBelowZero = ef.count_below_zero(res)
    freqMax = ef.fre_max(res)
    # rav1=ef.auto_var(res,1)
    # rav12=ef.auto_var(res,12)
    # rav24=ef.auto_var(res,24)
    # ravc1=ef.auto_var_coeff(res,1,fVar)
    # ravc12 = ef.auto_var_coeff(res, 12, fVar)
    # ravc24 = ef.auto_var_coeff(res, 24, fVar)

    newf = np.hstack((fEnergy, gAbsSC, rAboveZero, rBelowZero))
    # av=np.hstack((rav1,rav12,rav24,ravc1,ravc12,ravc24))

    # skewness = ef.skewness_res(res)
    kurtosis = ef.kurtosis_res(res)
    extreme_measure = ef.extremum_measure_sofvariation(res)
    stat_append = np.hstack(( kurtosis, extreme_measure))
    # feature = cov
    feature = np.hstack(
        (feature, res, grad, hess1, mu, stat, rStat, newf, stat_append))

    print(np.array(feature).shape)
    return feature


def gen_feature_index():
    feature_map = {'origin_data': [0, 40], 'res': [40, 34], 'grad_1': [74, 34], 'grad_12': [108, 34],
                   'grad_24': [142, 34],
                   'hess_1': [176, 34],
                   'hess_12': [210, 34], 'hess_24': [244, 34], 'mutation': [278, 34], 'mutation_max': [312, 34],
                   'mutation_12': [346, 34],
                   'mutation_12h': [380, 34], 'sum': [414, 34], 'sum_8': [448, 34], 'f_max': [482, 34],
                   'f_min': [516, 34],
                   'f_mean': [550, 34], 'cov_1': [584, 34], 'cov_2': [618, 34], 'cov_la': [652, 34],
                   'r_stat': [686, 34],
                   'g_stat': [690, 34], 'h_stat': [694, 34], 'm_stat': [698, 34]}
    np.save('feature_map.npy', feature_map, True)
    return


def dele_feature(feature, index):
    h, w = feature.shape
    for i in range(len(index)):
        id = index[i]
        if id > w:
            print("Delete Error! Index " + str(id) + " out of range !")
            return feature

    result = np.delete(feature, index, axis=1)
    return result


def insert_feature(new_data, feature, index=-1):
    h, w = feature.shape
    h2, w2 = new_data.shape
    if not h2 == h and w > index:
        print("Insert Error!")
        return feature

    if index == -1:
        result = np.hstack((feature, new_data))
    elif index == 0:
        result = np.hstack((new_data, feature))
    else:
        result = np.full((h, w + w2), np.nan)
        result[:, :index] = feature[:, :index]
        result[:, index:index + w2] = new_data
        result[:, index + w2:] = feature[:, index:]
    return result


def genFeatureLabels():
    exlen = 34
    # norm = np.char.add(featureName, '_norm')
    res = np.char.add(featureName[:exlen], '_residual')
    grad1 = np.char.add(featureName[:exlen], '_grad1')
    grad12 = np.char.add(featureName[:exlen], '_grad12')
    grad24 = np.char.add(featureName[:exlen], '_grad24')
    hess1 = np.char.add(featureName[:exlen], '_hess1')
    hess12 = np.char.add(featureName[:exlen], '_hess12')
    hess24 = np.char.add(featureName[:exlen], '_hess24')
    mutation = np.char.add(featureName[:exlen], '_mutation')
    mutationMax = np.char.add(featureName[:exlen], '_mutation_max')
    # mutation12 = np.char.add(featureName[:exlen], '_mutation_12')
    mutation12h = np.char.add(featureName[:exlen], '_mutation_12h')
    fSum = np.char.add(featureName[:exlen], '_cumulative_sum')
    fSum8 = np.char.add(featureName[:exlen], '_cumulative_sum_8')
    fMax = np.char.add(featureName[:exlen], '_max')
    fMin = np.char.add(featureName[:exlen], '_min')
    fMean = np.char.add(featureName[:exlen], '_mean')
    fVar = np.char.add(featureName[:exlen], '_var')
    # fMedian = np.char.add(featureName[:exlen], '_median')
    fCov = np.char.add(featureName[:exlen], '_filter1')
    fCov2 = np.char.add(featureName[:exlen], '_filter2')
    fCov3 = np.char.add(featureName[:exlen], '_laplace_filter')

    rMax = ['origin_feature_max']
    rMin = ['origin_feature_min']
    rMean = ['origin_feature_mean']
    rSum = ['origin_feature_sum']

    gMax = ['gradient_feature_max']
    gMin = ['gradient_feature_min']
    gMean = ['gradient_feature_mean']
    gSum = ['gradient_feature_sum']

    hMax = ['hess_feature_max']
    hMin = ['hess_feature_min']
    hMean = ['hess_feature_mean']
    hSum = ['hess_feature_sum']

    mMax = ['mutation_feature_max']
    mMin = ['mutation_feature_min']
    mMean = ['mutation_feature_mean']
    mSum = ['mutation_feature_sum']

    features_name = np.concatenate(
        (featureName, res, grad1, grad12, grad24, hess1, hess12, hess24, mutation, mutationMax, mutation12h,
         fSum, fSum8, fMax, fMin, fMean, fVar, fCov, fCov2, fCov3, rMax, rMin, rMean, rSum, gMax, gMin, gMean, gSum,
         hMax,
         hMin, hMean, hSum, mMax, mMin, mMean, mSum), axis=0)
    print(features_name)
    print(features_name.shape)
    np.save("feature_names.npy", features_name, True)
    return features_name


def deleInvalidData(feature, label, origin_label):
    dele = []
    h, w = np.array(feature).shape
    for i in range(h):
        nan = np.isnan(feature[i, :34])
        if np.sum(nan) >= 34:
            # print(feature[i, :34])
            dele.append(i)

    f = np.delete(feature, dele, axis=0)
    l = np.delete(label, dele, axis=0)
    ol = np.delete(origin_label, dele, axis=0)
    return np.array(f), np.array(l), np.array(ol)


def searchNearValue(index, list, range):
    indexL = index
    indexH = index
    while indexL >= max(index - range, 0) and indexH < min(index + range, len(list)):
        if np.isnan(list[indexL]) == False:
            return list[indexL]
        indexL = indexL - 1
    return list[index]


def get_origin_features(path):
    input_features = []
    input_labels = []
    input_origin_labels = []
    features_names = []
    labels_names = []
    origin_labels_names = []
    for i in range(len(path)):
        temp = os.listdir(path[i])
        temp = sorted(f for f in temp if os.path.isfile(os.path.join(path[i], f)) and f.endswith('.npy'))

        for j in range(len(temp)):
            parseName = temp[j].split('-')
            # print(parseName)
            if parseName[0] == 'feature_data':
                data = np.load(os.path.join(path[i], temp[j]))
                if len(input_features) == 0:
                    input_features = data
                else:
                    input_features = np.concatenate((input_features, data), axis=0)

                    print(input_features.shape)
                # input_features.append(data)
                features_names.append(parseName)
            elif parseName[0] == 'label_data':
                data = np.load(os.path.join(path[i], temp[j]))
                if len(input_labels) == 0:
                    input_labels = data
                else:
                    input_labels = np.concatenate((input_labels, data), axis=0)
                    print(input_labels.shape)

                labels_names.append(parseName)
            elif parseName[0] == 'origin_label_data':
                data = np.load(os.path.join(path[i], temp[j]))
                if len(input_origin_labels) == 0:
                    input_origin_labels = data
                else:
                    input_origin_labels = np.concatenate((input_origin_labels, data), axis=0)
                    print(input_origin_labels.shape)

                origin_labels_names.append(parseName)

    if np.all(np.array(features_names)[:, 1] == np.array(labels_names)[:, 1]):
        print('alignment check OK!')
    else:
        print('alignment check FALSE!')
        print(np.array(features_names).shape, np.array(features_names)[:, 1])
        print(np.array(labels_names).shape, np.array(labels_names)[:, 1])
    return input_features, input_labels, input_origin_labels


# 读取训练集特征值
# 输入：特征值文件夹路径、分类结果文件夹路径、非连续特征值名称、连续特征值名称
# 输出：患病特征值、正常特征值、所有特征值、所有特征值标签
def genFeatures(path, output_path):
    input_features, input_labels, input_origin_labels = get_origin_features(path)

    n = len(input_labels)

    instances_per_shard = 2000
    num_shards = int(n / 2000) + 1

    for i in range(num_shards):
        curFtr = []
        curResult = []
        curOriginResult = []
        # 将data写入npy文件。
        for j in range(instances_per_shard):
            # Example结构仅包含当前样例属于第几个文件以及是当前文件的第几个样本。
            index = j + i * 2000
            if index >= n:
                break
            feature = np.array(input_features[i * 2000 + j])
            feature = np.array(getFeature(feature)).astype('float32')
            label = np.array(input_labels[i * 2000 + j]).astype('int8')
            origin_label = np.array(input_origin_labels[i * 2000 + j]).astype('int8')

            curFtr.append(feature)
            curResult.append(label)
            curOriginResult.append(origin_label)

        basename = ("_data-%.4d-of-%.4d.npy" % (i + 1, num_shards))
        np.save(output_path + "feature" + basename, curFtr, True)
        np.save(output_path + "label" + basename, curResult, True)
        np.save(output_path + "origin_label" + basename, curOriginResult, True)

    return


def getFeatures(path):
    features = []
    labels = []
    origin_labels = []
    features_names = []
    labels_names = []
    origin_labels_names = []

    temp = os.listdir(path)
    temp = sorted(f for f in temp if os.path.isfile(os.path.join(path, f)) and f.endswith('.npy'))

    for j in range(len(temp)):
        parseName = temp[j].split('-')
        if parseName[0] == 'feature_data':
            data = np.load(os.path.join(path, temp[j]))
            if len(features) == 0:
                features = data
                # print(0, features.shape)
            else:
                # print('data',data.shape)
                features = np.concatenate((features, data), axis=0)
                # print(features.shape)
            # input_features.append(data)
            features_names.append(parseName)
        elif parseName[0] == 'label_data':
            data = np.load(os.path.join(path, temp[j]))
            if len(labels) == 0:
                labels = data
                # print(0, labels.shape)
            else:
                labels = np.concatenate((labels, data), axis=0)
                # print(labels.shape)
            labels_names.append(parseName)
        elif parseName[0] == 'origin_label_data':
            data = np.load(os.path.join(path, temp[j]))
            if len(origin_labels) == 0:
                origin_labels = data
                # print(0, labels.shape)
            else:
                origin_labels = np.concatenate((origin_labels, data), axis=0)
                # print(labels.shape)
            origin_labels_names.append(parseName)

    if np.all(np.array(features_names)[:, 1] == np.array(labels_names)[:, 1]) and np.all(
            np.array(features_names)[:, 1] == np.array(origin_labels_names)[:, 1]):
        print('alignment check OK!')
    else:
        print('alignment check FALSE!')
        print(np.array(features_names).shape, np.array(features_names)[:, 1])
        print(np.array(labels_names).shape, np.array(labels_names)[:, 1])

    return features, labels, origin_labels


def gen_feature_stat_info(path):
    features, labels, origin_labels = getFeatures(path)
    all_f = np.concatenate(features)
    mean = np.nanmean(all_f, axis=0)
    median = np.nanmedian(all_f, axis=0)
    max = np.nanmax(all_f, axis=0)
    min = np.nanmin(all_f, axis=0)
    var = np.nanvar(all_f, axis=0)
    std = np.nanstd(all_f, axis=0)
    np.save('feature_mean_numpy.npy', mean)
    np.save('feature_median_numpy.npy', median)
    np.save('feature_max_numpy.npy', max)
    np.save('feature_min_numpy.npy', min)
    np.save('feature_var_numpy.npy', var)
    np.save('feature_std_numpy.npy', std)
    return


def ImputerMissingValue(path, start=0, way='median'):
#    if os.path.exists("./feature_mean_numpy.npy") and os.path.exists("./feature_median_numpy.npy"):
#        print("Generate statistic info first!")
#        return

    imr1 = np.load("feature_median_numpy.npy")
    print(imr1)
    imr2 = np.load("feature_mean_numpy.npy")
    temp = os.listdir(path)
    temp = sorted(f for f in temp if os.path.isfile(os.path.join(path, f)) and f.endswith('.npy'))
    for f in range(len(temp)):
        parseName = temp[f].split('-')
        if parseName[0] == 'feature_data':
            file_path = os.path.join(path, temp[f])
            data = np.load(file_path)
            for k in range(len(data)):
                h, w = data[k].shape
                for i in range(h):
                    for j in range(w-start):
                        if np.isnan(data[k][i, j+start]):
                            if way == 'median':
                                data[k][i, j + start] = imr1[j + start]
                            elif way == 'mean':
                                data[k][i, j + start] = imr2[j + start]
            np.save(file_path, data, True)
    return


def ImputerInf(path):

    temp = os.listdir(path)
    temp = sorted(f for f in temp if os.path.isfile(os.path.join(path, f)) and f.endswith('.npy'))
    for f in range(len(temp)):
        parseName = temp[f].split('-')
        if parseName[0] == 'feature_data':
            file_path = os.path.join(path, temp[f])
            data = np.load(file_path)
            for k in range(len(data)):
                # h, w = data[k].shape
                index=np.argwhere(np.isinf(data[k]))
                for i in range(len(index)):

                    data[k][index[i]]=99999999

            np.save(file_path, data, True)
    return

def init():
    path = ["./origin_data/train/"]
    npy_data_path = "./npy_data/origin_data/test/"
    npy_feature_path = './npy_data/test/'

#    genNpyData.genData(path, npy_data_path)
    genFeatures([npy_data_path], npy_feature_path)
#    genFeatureLabels()
#     gen_feature_stat_info(npy_feature_path)
    ImputerMissingValue(npy_feature_path, 40, 'median')
#     ImputerInf(npy_feature_path)
    return


if __name__ == "__main__":
    # max_f=np.load('feature_max_numpy.npy')
#    print("start")
#    npy_feature_path = './npy_data/train_temp/'
#    ImputerMissingValue(npy_feature_path, 40, 'median')
#    print("end")
    init()
#    print(x_mean)
#    result = insert_feature(np.array([[12, 13]]), np.reshape(x_mean, (1, 40)), 0)
#    print(result)
#    gen_feature_index()
#    z = np.load('feature_map.npy')
#    print(z)
    # test = GetFeatures.readData('./training/p000050.psv')
    # feature = GetFeatures.getFeature(test)

    # test = np.arange(1, 101, 1)
    # test = np.reshape(test, (50, 2))
    # print(test)
    # result = getFeature(test, True)
    # print(result)

    # genFeatures(["./npy_data_mixAB/unit1/"], './features_labels_mixAB/unit1/', True)
    # genFeatures(["./npy_data_mixAB/unit2/"], './features_labels_mixAB/unit2/', True)
    # genFeatureLabels()
    # getFeatures('./features_labels/')
    # init()
    # gen_regression_label('./features_labels/', './features_labels/')
    # genFeatures(["./npy_data_mixAB/train_temp/"], './features_labels_mixAB/train_temp/')
    # genFeatures(["./npy_data_mixAB/test_temp/"], './features_labels_mixAB/test_temp/')
    # x = np.load('./features_labels/temp_test/feature_data-0016-of-0017.npy')
    # t = np.concatenate(x, axis=0)
    exit(0)
