import get_sepsis_score
import GetFeatures
import extractFeatures
import numpy as np
import fast_feature_gen

import joblib
import os


def ImputerMissingValue(feature, start=0, way='median'):
    imr = np.load("score_median.npy")

    h, w = feature.shape
    for i in range(h):
        for j in range(w - start):
            if np.isnan(feature[i, j + start]):
                feature[i, j + start] = imr[j + start]
    return feature


if __name__ == '__main__':

    input_files = []
    path = ['E:\physionet0424\\test_temp']
    for i in range(len(path)):
        temp = os.listdir(path[i])
        temp = sorted(f for f in temp if os.path.isfile(os.path.join(path[i], f)) and f.endswith('.psv'))
        for j in range(len(temp)):
            input_files.append(os.path.join(path[i], temp[j]))

    for k in range(len(input_files)):
        # print(input_files[k])
        data = GetFeatures.readData(input_files[k])
        feature = data[:, :-1]
        f2 = np.copy(feature)
        f1 = np.copy(feature)
        f3 = np.copy(feature)
        num_rows = len(data)
        f_2 = GetFeatures.getFeature(f2)
        f_2 = ImputerMissingValue(f_2, 40, 'median')
        f_2 = np.array(f_2).astype('float32')
        f_1 = np.full_like(f_2, np.nan)
        f_3 = np.full_like(f_2, np.nan)
        f_7 = np.full_like(f_2, np.nan)

        for t in range(num_rows):
            current_data = f1[:t + 1]
            current_data2 = f3[:t + 1]
            f_1[t, :] = get_sepsis_score.genFeature(current_data)
            f_7[t, :] = fast_feature_gen.gen_all_feature(current_data)

            f_3[t, :] = f_1[t] - f_7[t]

        max = np.nansum(f_3)
        if max != 0:
            print(input_files[k])
            print('sum', max)

    # x_mean = np.array([
    #     83.8996, 97.0520, 36.8055, 126.2240, 86.2907,
    #     66.2070, 18.7280, 33.7373, -3.1923, 22.5352,
    #     0.4597, 7.3889, 39.5049, 96.8883, 103.4265,
    #     22.4952, 87.5214, 7.7210, 106.1982, 1.5961,
    #     0.6943, 131.5327, 2.0262, 2.0509, 3.5130,
    #     4.0541, 1.3423, 5.2734, 32.1134, 10.5383,
    #     38.9974, 10.5585, 286.5404, 198.6777,
    #     60.8711, 0.5435, 0.0615, 0.0727, -59.6769, 28.4551])
    # data = GetFeatures.readData('./p014001.psv')
    # feature = data[:, :-1]
    # h, w = feature.shape
    # for j in range(w):
    #     for i in range(h):
    #         if np.isnan(feature[i, j]):
    #             feature[i, j] = x_mean[j]
    #
    # f2 = np.copy(feature)
    # f1 = np.copy(feature)
    # f3 = np.copy(feature)
    # num_rows = len(data)
    # f_2 = GetFeatures.getFeature(f2)
    # f_2 = ImputerMissingValue(f_2, 40, 'median')
    # f_2 = np.array(f_2).astype('float32')
    #
    # f_1 = np.full_like(f_2, np.nan)
    # f_3 = np.full_like(f_2, np.nan)
    # f_7 = np.full_like(f_2, np.nan)
    #
    # for t in range(num_rows):
    #     current_data = f1[:t + 1]
    #     current_data2 = f3[:t + 1]
    #     f_temp = get_sepsis_score.genFeature(current_data)
    #     f_temp2 = fast_feature_gen.gen_all_feature(current_data2)
    #     f_1[t, :] = f_temp
    #     f_7[t, :] = f_temp2
    #     f_3[t, :] = f_temp - f_7[t]
    # max = np.nansum(f_3)
    # print('sum', max)
    #
    # data2 = GetFeatures.readData('./p014003.psv')
    # feature2 = data2[:, :-1]
    # h, w = feature2.shape
    # for j in range(w):
    #     for i in range(h):
    #         if np.isnan(feature2[i, j]):
    #             feature2[i, j] = x_mean[j]
    # f4 = np.copy(feature2)
    # f3 = np.copy(feature2)
    # f5 = np.copy(feature2)
    # num_rows2 = len(data2)
    # f_4 = GetFeatures.getFeature(f4)
    # f_4 = ImputerMissingValue(f_4, 40, 'median')
    # f_4 = np.array(f_4).astype('float32')
    # # f_index = utils.kind_feature_filter([11, 25], True)
    #
    # # f_2 = f_2[:, f_index]
    # f_5 = np.full_like(f_4, np.nan)
    # f_6 = np.full_like(f_4, np.nan)
    # f_8 = np.full_like(f_4, np.nan)
    # for t in range(num_rows2):
    #     current_data = f3[:t + 1]
    #     current_data2 = f5[:t + 1]
    #     f_temp = get_sepsis_score.genFeature(current_data)
    #     f_temp2=fast_feature_gen.gen_all_feature(current_data2)
    #     f_5[t, :] = f_temp
    #     f_8[t, :] = f_temp2
    #     f_6[t, :] = f_temp - f_8[t]
    # max2 = np.nansum(f_6)
    # error = []
    # # error[:, kind_feature_filter([9, 10, 11, 12, 24])]
    # print('sum2', max2)
