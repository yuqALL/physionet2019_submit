# -*- coding: UTF-8 -*-
# !/usr/bin/python

import numpy as np
import math

fMax = np.array([
    280.00, 100.00, 50.00, 300.00, 300.00, 300.00, 100.00, 100.00,
    100.00, 55.00, 4000.00, 7.93, 100.00, 100.00, 9961.00, 268.00,
    3833.00, 27.90, 145.00, 46.60, 37.50, 988.00, 31.00, 9.80,
    18.80, 27.50, 49.60, 440.00, 71.70, 32.00, 250.00, 440.00,
    1760.00, 2322.00, 100.00, 1.00, 1.00, 1.00, 23.99, 336.00
])

fMin = np.array([
    20.00, 20.00, 20.90, 20.00, 20.00, 20.00, 1.00, 10.00,
    -32.00, 0.00, -50.00, 6.62, 10.00, 23.00, 3.00, 1.00,
    7.00, 1.00, 26.00, 0.10, 0.01, 10.00, 0.20, 0.20,
    0.20, 1.00, 0.10, 0.01, 5.50, 2.20, 12.50, 0.10,
    34.00, 1.00, 14.00, 0.00, 0.00, 0.00, -5366.86, 1.00
])

x_mean = np.array([
    83.8996, 97.0520, 36.8055, 126.2240, 86.2907,
    66.2070, 18.7280, 33.7373, -3.1923, 22.5352,
    0.4597, 7.3889, 39.5049, 96.8883, 103.4265,
    22.4952, 87.5214, 7.7210, 106.1982, 1.5961,
    0.6943, 131.5327, 2.0262, 2.0509, 3.5130,
    4.0541, 1.3423, 5.2734, 32.1134, 10.5383,
    38.9974, 10.5585, 286.5404, 198.6777,
    60.8711, 0.5435, 0.0615, 0.0727, -59.6769, 28.4551])

x_std = np.array([
    17.6494, 3.0163, 0.6895, 24.2988, 16.6459,
    14.0771, 4.7035, 11.0158, 3.7845, 3.1567,
    6.2684, 0.0710, 9.1087, 3.3971, 430.3638,
    19.0690, 81.7152, 2.3992, 4.9761, 2.0648,
    1.9926, 45.4816, 1.6008, 0.3793, 1.3092,
    0.5844, 2.5511, 20.4142, 6.4362, 2.2302,
    29.8928, 7.0606, 137.3886, 96.8997,
    16.1887, 0.4981, 0.7968, 0.8029, 160.8846, 29.5367])

fN = fMax - fMin

pre_residual = []
pre_grad1 = []
pre_grad12 = []
pre_grad24 = []
energy_pre = []
abs_grad = []
abs_hess = []
count_above = []
count_below = []
pre_power_3_skewness = []
pre_power_2_skewness = []
pre_power_4_kurtosis = []
pre_power_2_kurtosis = []
fSum_pre = []
fmax = []
fmin = []
grad_temp = []
hess_temp = []
All_grad1 = []

exlen = 34

list_d = [5, 7, 8, 10, 18, 19, 20, 22, 23, 24, 27, 30, 31]

imr = np.load("score_median.npy")


def gen_all_feature(data):
    global pre_residual, pre_grad1, exlen, \
        fSum_pre, fmax, fmin, energy_pre, abs_grad, \
        count_above, count_below,  \
        pre_power_4_kurtosis, pre_power_2_kurtosis, imr

    origin = np.copy(data)
    origin_split = origin[:, :exlen]

    h, w = origin.shape
    w = exlen

    if h == 1:
        pre_grad1 = []
        pre_residual = origin_split[-1] - x_mean[0:exlen]
        pre_residual = np.array(pre_residual)
        grad1 = imr[74:108]
        pre_grad1.append(grad1)
        mutation_1h = imr[176:210]

        fSum_pre = pre_residual
        fmax = pre_residual
        f_max = pre_residual
        fmin = pre_residual
        f_min = pre_residual
        f_mean = pre_residual

        f_var = np.zeros(w)
        energy_pre = np.power(pre_residual, 2)
        abs_grad = np.zeros(w)
        count_above = np.zeros(w)
        count_below = np.zeros(w)

        pre_power_2_kurtosis = np.power(pre_residual, 2)
        pre_power_4_kurtosis = np.power(pre_residual, 4)
        skew_temp = pre_power_2_kurtosis
        up2 = pre_power_4_kurtosis

        rMax = np.max(pre_residual)
        rMin = np.min(pre_residual)
        rMean = np.mean(pre_residual)
        rSum = np.sum(pre_residual)
        rStat = np.hstack((rMax, rMin, rMean, rSum))
        count_above += pre_residual > 0
        count_below += pre_residual < 0
        res = pre_residual

    else:

        pre_residual = np.vstack((pre_residual, (origin_split[-1] - x_mean[0:exlen])))
        grad1 = pre_residual[-1] - pre_residual[-2]
        sum_thred = np.full(w, 1000000)
        s = np.vstack((fSum_pre, pre_residual[-1]))
        fSum_pre = np.min(np.vstack((np.sum(s, axis=0), sum_thred)), axis=0)
        pre_grad1.append(grad1)
        f_mean = np.mean(pre_residual, axis=0)
        f_var = np.var(pre_residual, axis=0)
        mutation_1h = mFCac(pre_residual, f_mean)

        f_max = np.max(np.vstack((fmax, pre_residual[-1])), axis=0)
        fmax = f_max
        f_min = np.min(np.vstack((fmin, pre_residual[-1])), axis=0)
        fmin = f_min
        abs_grad += np.abs(grad1)
        energy_pre += np.power(pre_residual[-1], 2)

        pre_power_2_kurtosis = np.vstack((pre_power_2_kurtosis, np.power(pre_residual[-1], 2)))
        pre_power_4_kurtosis = np.vstack((pre_power_4_kurtosis, np.power(pre_residual[-1], 4)))
        skew_temp = np.sum(pre_power_2_kurtosis, axis=0)
        up2 = h * np.sum(pre_power_4_kurtosis, axis=0)

        rMax = np.max(pre_residual[-1])
        rMin = np.min(pre_residual[-1])
        rMean = np.mean(pre_residual[-1])
        rSum = np.sum(pre_residual[-1])
        rStat = np.hstack((rMax, rMin, rMean, rSum))
        count_above += pre_residual[-1] > 0
        count_below += pre_residual[-1] < 0

        res = pre_residual[-1]

    if h >= 13:
        grad12 = pre_residual[-1, :] - pre_residual[-13, :]
    elif h >= 7:
        grad12 = pre_residual[-1] - pre_residual[0]
    else:
        grad12 = imr[108:142]

    if h > 2:
        hess1 = pre_grad1[-1] - pre_grad1[-2]
    else:
        hess1 = imr[142:176]

    if h > 11:
        mutation_12 = mFCac(pre_residual[h - 12:h, :], np.mean(pre_residual[h - 12:h, :], axis=0))
    else:
        mutation_12 = imr[210:244]

    if h >= 8:
        f_sum8 = np.sum(pre_residual[h - 8:h, :], axis=0)
    else:
        f_sum8 = imr[278:312]

    down2 = np.power(skew_temp, 2)

    for j in range(w):
        if down2[j] < 0.00001:
            down2[j] = 0.0001
    ks = up2 / down2 - 3
    es = f_max - f_min
    f = np.hstack((
        origin[-1], res, grad1, grad12, hess1, mutation_1h, mutation_12, fSum_pre, f_sum8, f_max, f_min, f_mean, f_var,
        rStat, energy_pre, abs_grad, count_above, count_below, ks, es)).reshape((1, -1))

    f = np.array(f).astype('float32')
    return f


def mFCac(data, mean):
    h, w = data.shape
    m_t = np.copy(mean)
    s_t = np.std(data, axis=0)
    for i in range(w):
        if m_t[i] < 0.001 and m_t[i] >= 0:
            m_t[i] = 0.001
        elif m_t[i] > -0.001 and m_t[i] < 0:
            m_t[i] = -0.001
    return np.divide(s_t, m_t)
