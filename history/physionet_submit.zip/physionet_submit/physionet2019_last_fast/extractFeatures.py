import numpy as np
import warnings
import math

warnings.filterwarnings('ignore')
np.seterr(divide='ignore', invalid='ignore')

x_mean = np.array([
    83.8996, 97.0520, 36.8055, 126.2240, 86.2907,
    66.2070, 18.7280, 33.7373, -3.1923, 22.5352,
    0.4597, 7.3889, 39.5049, 96.8883, 103.4265,
    22.4952, 87.5214, 7.7210, 106.1982, 1.5961,
    0.6943, 131.5327, 2.0262, 2.0509, 3.5130,
    4.0541, 1.3423, 5.2734, 32.1134, 10.5383,
    38.9974, 10.5585, 286.5404, 198.6777,
    60.8711, 0.5435, 0.0615, 0.0727, -59.6769, 28.4551])

x_std = np.array([
    17.6494, 3.0163, 0.6895, 24.2988, 16.6459,
    14.0771, 4.7035, 11.0158, 3.7845, 3.1567,
    6.2684, 0.0710, 9.1087, 3.3971, 430.3638,
    19.0690, 81.7152, 2.3992, 4.9761, 2.0648,
    1.9926, 45.4816, 1.6008, 0.3793, 1.3092,
    0.5844, 2.5511, 20.4142, 6.4362, 2.2302,
    29.8928, 7.0606, 137.3886, 96.8997,
    16.1887, 0.4981, 0.7968, 0.8029, 160.8846, 29.5367])

fMax = np.array([
    280.00, 100.00, 50.00, 300.00, 300.00, 300.00, 100.00, 100.00,
    100.00, 55.00, 4000.00, 7.93, 100.00, 100.00, 9961.00, 268.00,
    3833.00, 27.90, 145.00, 46.60, 37.50, 988.00, 31.00, 9.80,
    18.80, 27.50, 49.60, 440.00, 71.70, 32.00, 250.00, 440.00,
    1760.00, 2322.00, 100.00, 1.00, 1.00, 1.00, 23.99, 336.00
])

fMin = np.array([
    20.00, 20.00, 20.90, 20.00, 20.00, 20.00, 1.00, 10.00,
    -32.00, 0.00, -50.00, 6.62, 10.00, 23.00, 3.00, 1.00,
    7.00, 1.00, 26.00, 0.10, 0.01, 10.00, 0.20, 0.20,
    0.20, 1.00, 0.10, 0.01, 5.50, 2.20, 12.50, 0.10,
    34.00, 1.00, 14.00, 0.00, 0.00, 0.00, -5366.86, 1.00
])

x_mean = np.array([
    83.8996, 97.0520, 36.8055, 126.2240, 86.2907,
    66.2070, 18.7280, 33.7373, -3.1923, 22.5352,
    0.4597, 7.3889, 39.5049, 96.8883, 103.4265,
    22.4952, 87.5214, 7.7210, 106.1982, 1.5961,
    0.6943, 131.5327, 2.0262, 2.0509, 3.5130,
    4.0541, 1.3423, 5.2734, 32.1134, 10.5383,
    38.9974, 10.5585, 286.5404, 198.6777,
    60.8711, 0.5435, 0.0615, 0.0727, -59.6769, 28.4551])

x_std = np.array([
    17.6494, 3.0163, 0.6895, 24.2988, 16.6459,
    14.0771, 4.7035, 11.0158, 3.7845, 3.1567,
    6.2684, 0.0710, 9.1087, 3.3971, 430.3638,
    19.0690, 81.7152, 2.3992, 4.9761, 2.0648,
    1.9926, 45.4816, 1.6008, 0.3793, 1.3092,
    0.5844, 2.5511, 20.4142, 6.4362, 2.2302,
    29.8928, 7.0606, 137.3886, 96.8997,
    16.1887, 0.4981, 0.7968, 0.8029, 160.8846, 29.5367])

fN = fMax - fMin


def normalization(item):
    global fMin, fMax, fN
    item = np.array(item)
    temp = (item - fMin) / fN
    norm = np.ones_like(temp)
    lower = np.zeros_like(temp)
    temp = np.minimum(temp, norm)
    result = np.maximum(temp, lower)
    return result


def feature_normalization(feature):
    h, w = feature.shape
    norm = np.full((h, w), np.nan)
    higher = np.ones_like(w)
    lower = np.zeros_like(w)
    for i in range(h):
        norm[i] = (feature[i] - fMin[:w]) / fN[:w]
        norm[i] = np.minimum(norm[i], higher)
        norm[i] = np.maximum(norm[i], lower)
    return norm


def data_norm(feature):
    h, w = feature.shape
    norm = np.full((h, w), np.nan)
    for i in range(h):
        norm[i] = (feature[i] - x_mean) / x_std
    return norm


def featureGrad(feature):
    h, w = np.array(feature).shape
    grad = np.full(np.array(feature).shape, np.nan)
    for i in range(h):
        for j in range(w):
            if i > 0 and not np.isnan(feature[i - 1, j]):
                grad[i, j] = feature[i, j] - feature[i - 1, j]

    # if h > 1 and isTrain:
    #     grad[0, :] = grad[1, :]
    return grad


def featureGrad_12(feature):
    h, w = np.array(feature).shape
    grad = np.full(np.array(feature).shape, np.nan)
    for i in range(h):
        for j in range(w):
            if i >= 12 and not np.isnan(feature[i - 12, j]):
                grad[i, j] = feature[i, j] - feature[i - 12, j]
            elif i >= 6 and not np.isnan(feature[0, j]):
                grad[i, j] = feature[i, j] - feature[0, j]
    return grad


def featureGrad_24(feature):
    h, w = np.array(feature).shape
    grad = np.full(np.array(feature).shape, np.nan)
    for i in range(h):
        for j in range(w):
            if i >= 24 and not np.isnan(feature[i - 24, j]):
                grad[i, j] = feature[i, j] - feature[i - 24, j]
            elif i >= 15 and not np.isnan(feature[0, j]):
                grad[i, j] = feature[i, j] - feature[0, j]
    return grad


def mFCac(data):
    h, w = data.shape
    m_t = np.nanmean(data, axis=0)
    s_t = np.nanstd(data, axis=0)
    for i in range(w):
        if np.isnan(m_t[i]):
            m_t[i] = x_mean[i]
        if np.isnan(s_t[i]):
            s_t[i] = x_std[i]
        if m_t[i] < 0.001 and m_t[i] >= 0:
            m_t[i] = 0.001
        elif m_t[i] > -0.001 and m_t[i] <= 0:
            m_t[i] = -0.001
    return np.divide(s_t, m_t)


def mutationFactor(feature):
    f = np.array(feature)
    h, w = f.shape
    mutation = []
    tNan = np.zeros(w)
    tNan[:] = np.nan
    for i in range(h):
        if i > 0:
            mutation.append(mFCac(f[0:i + 1, :]))
        else:
            mutation.append(tNan.tolist())
    return mutation


def mutationFactor_12(feature):
    h, w = feature.shape
    index_i = 0
    mutation = []
    tNan = np.zeros(w)
    tNan[:] = np.nan
    m_max = 0
    for i in range(h):
        if i < 11:
            mutation.append(tNan.tolist())
        elif i < 36:
            for j in range(i + 1 - 11):
                m_t_mean = np.nanmean(feature[j:j + 11, :], axis=0)
                m_t_max = np.nanmax(feature[j:j + 11, :], axis=0)
                m_t_min = np.nanmin(feature[j:j + 11, :], axis=0)
                m_t = m_t_mean / ((m_t_max - m_t_min) + 1e-3)
                m_t_all = np.nansum(m_t[:8])
                if m_t_all > m_max:
                    m_max = m_t_all
                    index_i = j
            if i - index_i + 1 <= 12:
                mutation.append(mFCac(feature[index_i:i + 1, :]))
            else:
                k = int((i - index_i) / 12)
                # print(i, index_i + k * 12,index_i)
                mutation.append(mFCac(feature[index_i + k * 12:i + 1, :]))
        else:
            k = int((i - index_i) / 12)
            # print(i,index_i + k * 12,index_i)
            mutation.append(mFCac(feature[index_i + k * 12:i + 1, :]))
    return mutation


# 12小时更新一次
def mutationFactor_12h(feature):
    f = np.array(feature)
    h, w = f.shape
    mutation = []
    tNan = np.zeros(w)
    tNan[:] = np.nan
    for i in range(h):
        if i < 11:
            mutation.append(tNan.tolist())
        else:
            mutation.append(mFCac(f[i - 11:i + 1, :]))
    return mutation


def mutationFactor_12_train(feature):
    f = np.array(feature)
    h, w = f.shape
    m_max = 0
    index_i = 0
    mutation = []
    for i in range(h):
        # m_t = np.mean(f[i:i + 11, :])
        if i + 11 < h:
            m_t = np.mean(f[i:i + 12, :], axis=0)
            m_t_all = np.sum(m_t)
            if m_t_all > m_max:
                m_max = m_t_all
                index_i = i
        if i > 23:
            break

    t = int((h - index_i) / 12) + 2
    for i in range(t):

        if i == 0:
            if index_i > 0:
                temp = mFCac(f[0:index_i, :])
                mutation = np.full((index_i, w), temp)
            else:
                continue
            # print(i, np.array(mutation).shape)
        else:
            j = i - 1
            if (index_i + j * 12 + 12) < h:
                temp = mFCac(f[index_i + j * 12:index_i + i * 12, :])

                if index_i == 0 and i == 1:
                    mutation = np.full((12, w), temp)
                else:
                    mutation = np.vstack((mutation, np.full((12, w), temp)))

                # print(i, np.array(mutation).shape)
            else:
                if (h - 1) >= (index_i + j * 12):
                    temp = mFCac(f[index_i + j * 12:h, :])
                    # print(mutation.shape, temp.shape)
                    if len(mutation):
                        mutation = np.vstack((mutation, np.full((h - index_i - j * 12, w), temp)))
                    else:
                        mutation = np.full((h - index_i - j * 12, w), temp)
                else:
                    continue
    return mutation


def mutationFactor_12_rotate(feature):
    f = np.array(feature)
    # print("f", np.array(f).shape)
    h, w = f.shape
    m_max = 0
    index_i = 0
    mutation = []
    for i in range(h):
        if i == 0:
            m_t = (np.copy(f[0, :]))
            s_t = (np.zeros((8,)))
            mutation.append(np.divide(s_t, m_t))
        elif i < 12:
            m_t = np.mean(f[0:i, :], axis=0)
            s_t = np.std(f[0:i, :], axis=0)
            mutation.append(np.divide(s_t, m_t))
        elif i < 24:
            for j in range(i - 11):
                # m_t = np.mean(f[i:i + 11, :])
                m_t = np.mean(f[j:j + 11, :], axis=0)
                m_t_all = np.sum(m_t)
                if m_t_all > m_max:
                    m_max = m_t_all
                    index_i = j

            if i - index_i <= 12:
                m_t = np.mean(f[index_i:i, :], axis=0)
                s_t = np.std(f[index_i:i, :], axis=0)
                mutation.append(np.divide(s_t, m_t))
            else:
                k = (int((i - index_i) / 12) + 1) % 2
                if k == 0:
                    m_t = np.mean(f[index_i:index_i + 11, :], axis=0)
                    s_t = np.std(f[index_i:index_i + 11, :], axis=0)
                    mutation.append(np.divide(s_t, m_t))
                else:
                    m_t = np.mean(f[index_i + k * 12:i, :], axis=0)
                    s_t = np.std(f[index_i + k * 12:i, :], axis=0)
                    mutation.append(np.divide(s_t, m_t))

        else:
            k = (int((i - index_i) / 12) + 1) % 2
            if k == 0:
                m_t = np.mean(f[index_i:index_i + 11, :], axis=0)
                s_t = np.std(f[index_i:index_i + 11, :], axis=0)
                mutation.append(np.divide(s_t, m_t))
            else:
                if i - index_i > 23:
                    m_t = np.mean(f[index_i + 12:index_i + 23, :], axis=0)
                    s_t = np.std(f[index_i + 12:index_i + 23, :], axis=0)
                    mutation.append(np.divide(s_t, m_t))
                else:
                    m_t = np.mean(f[index_i + 12:i, :], axis=0)
                    s_t = np.std(f[index_i + 12:i, :], axis=0)
                    mutation.append(np.divide(s_t, m_t))

    return mutation


def muFactor_max(feature):
    f = np.array(feature)
    h, w = f.shape
    mutation = []
    tNan = np.zeros(w)
    tNan[:] = np.nan
    validV = 0
    for i in range(h):
        if i < 11:
            mutation.append(tNan.tolist())
        else:
            value = f[i - 11:i + 1, :]
            mV = mFCac(value)
            if validV >= 2:
                # splitV = np.nanmean(mutation, axis=0)
                splitV = np.nanmedian(mutation, axis=0)
                temp = np.zeros_like(splitV)
                for j in range(len(splitV)):
                    if splitV[j] > mV[j]:
                        min = np.nanmin(np.array(mutation)[:, j], axis=0)
                        temp[j] = [min, mV[j]][bool(min > mV[j])]
                    else:
                        max = np.nanmax(np.array(mutation)[:, j], axis=0)
                        temp[j] = [max, mV[j]][bool(max < mV[j])]
                mutation.append(temp)
            else:
                mutation.append(mV)
                validV += 1
    return mutation


def featureSum(feature):
    f = np.array(feature)
    h, w = f.shape
    sum = []
    thred = np.full((h, w), 1000000)
    for i in range(h):
        temp = np.min(np.vstack((np.sum(f[0:i + 1, :], axis=0), thred)), axis=0)
        sum.append(temp)
    return sum


def featureSum_8h(feature):
    f = np.array(feature)
    h, w = f.shape
    sum = []
    tNan = np.zeros(w)
    tNan[:] = np.nan
    for i in range(h):
        if i < 7:
            temp = tNan.tolist()
        else:
            temp = np.nansum(f[i - 7:i + 1, :], axis=0)
        sum.append(temp)
    return sum


def featureMax(feature):
    f = np.array(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        temp = np.nanmax(f[:i + 1, :], axis=0)
        m.append(temp)
    return m


def featureMin(feature):
    f = np.array(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        temp = np.nanmin(f[:i + 1, :], axis=0)
        m.append(temp)
    return m


def featureMean(feature):
    f = np.array(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        temp = np.nanmean(f[:i + 1, :], axis=0)
        m.append(temp)
    return m


def featureVar(feature):
    f = np.array(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        temp = np.nanvar(f[:i + 1, :], axis=0)
        m.append(temp)
    return m


def featureMedian(feature):
    f = np.array(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        temp = np.nanmedian(f[:i + 1, :], axis=0)
        m.append(temp)
    return m


def listMax(feature):
    h, w = feature.shape
    result = np.nanmax(np.array(feature), axis=1)
    return np.reshape(result, (h, 1))


def listMin(feature):
    h, w = feature.shape
    result = np.nanmin(np.array(feature), axis=1)
    return np.reshape(result, (h, 1))


def listMean(feature):
    h, w = feature.shape
    result = np.nanmean(np.array(feature), axis=1)
    return np.reshape(result, (h, 1))


def listSum(feature):
    h, w = feature.shape
    result = np.nansum(np.array(feature), axis=1)
    return np.reshape(result, (h, 1))


def residualValue(feature):
    h, w = feature.shape
    data = np.full((h, w), x_mean[0:w])
    return feature - data


def covFilter(feature):
    h, w = feature.shape
    f = np.full((h + 4, w), 0)
    f[2:-2, :] = feature
    result = np.full((h, w), np.nan)
    for i in range(h):
        # print(f[:, j].shape)
        result[i, :] = (f[i + 2, :] + f[i + 1, :] * 2 + f[i, :]) / 4
    return result


def Filter2d(feature, kernel):
    # 3x3 kernel
    h, w = feature.shape
    tmp = np.zeros((h + 2, w + 2), dtype='float32')
    tmp[2:, 2:] = feature
    result = np.full((h, w), np.nan)
    for i in range(h):
        for j in range(w):
            t = tmp[i:i + 3, j:j + 3] * kernel
            result[i, j] = np.sum(t)
    return result


def compare(value, left, right):
    if np.isnan(value):
        return 0
    if value > right:
        return 1
    elif value > left:
        return 0
    else:
        return -1


def genObs(list):
    result = []
    result.append(compare(list[0], 60, 150))
    result.append(compare(list[1], 91, 99))
    result.append(compare(list[2], 36.5, 37.3))
    result.append(compare(list[3], 90, 139))
    result.append(compare(list[4], 65, 110))
    result.append(compare(list[5], 50, 92))
    result.append(compare(list[6], 12, 60))
    result.append(compare(list[7], 35, 45))
    result.append(compare(list[8], -10, 6))
    result.append(compare(list[9], 23, 30))
    result.append(compare(list[10], 0.6, 0.98))
    result.append(compare(list[11], 6, 8))
    return result


def getObsfeature(feature):
    h, w = feature.shape
    result = []
    for i in range(h):
        result.append(genObs(feature[i, :12]))
    return np.reshape(result, (h, 12))


def three_hour_prior(features):
    h, w = features.shape
    result = np.zeros((h, w * 5))
    result[:, :w] = features
    for i in range(h):
        if i >= 2:
            result[i, w:2 * w] = features[i - 1, :]
            result[i, 2 * w:3 * w] = features[i - 2, :]
            result[i, 3 * w:4 * w] = features[i, :] - features[i - 1, :]
            result[i, 4 * w:5 * w] = features[i, :] - features[i - 2, :]
        elif i > 0:
            result[i, w:2 * w] = features[i - 1, :]
            result[i, 3 * w:4 * w] = features[i, :] - features[i - 1, :]
    return result


def fre_max(feature):
    f = np.copy(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        if i == 0:
            temp = np.zeros(w)
        else:
            sp = np.fft.fft(f[:i + 1, :], axis=0)
            max_f = np.zeros(w)
            for k in range(i + 1):
                max_f = np.max(np.vstack((np.sqrt(sp[k].real ** 2 + sp[k].imag ** 2), max_f)), axis=0)
            temp = max_f
        m.append(temp)
    return np.array(m)


def abs_energy(feature):
    f = np.copy(feature)
    h, w = f.shape
    m = []
    for i in range(h):
        temp = np.zeros(w)
        for k in range(i + 1):
            temp += np.power(f[k], 2)
        m.append(temp)
    return np.array(m)


def absolute_sum(feature):
    ##NaN处理
    h, w = np.array(feature).shape
    f = np.copy(feature)
    m = []
    for i in range(h):
        for j in range(w):
            if np.isnan(f[i, j]):
                f[i, j] = 0
        temp = np.zeros(w)
        for k in range(i + 1):
            temp += np.abs(f[k])
        m.append(temp)
    return m


def count_above_zero(feature):
    h, w = np.array(feature).shape
    m = np.zeros((h, w))
    for i in range(h):
        for k in range(i + 1):
            m[i] += feature[k] > 0

    return m


def count_below_zero(feature):
    h, w = np.array(feature).shape
    m = np.zeros((h, w))
    for i in range(h):
        for k in range(i + 1):
            m[i] += feature[k] < 0

    return m


def auto_var(data, k):
    feature = np.copy(data)
    h, w = feature.shape
    av = np.full((h, w), np.nan)
    if h <= k:
        return av
    # max_v = np.full((h, w), 1000000)
    for i in range(h):
        if i + 1 > k:
            temp = (i + 1 - k) * (np.nansum(feature[k:i + 1] * feature[0:i + 1 - k], axis=0))
            for j in range(w):
                if temp[j] < 0.00001 and temp[j] > 0.00001:
                    temp[j] = 0.00001

            av[i] = 1.0 / temp
    return av


def auto_var_coeff(data, k, var):
    feature = np.copy(data)
    h, w = feature.shape
    avc = np.full((h, w), np.nan)
    if h <= k:
        return avc
    var = np.array(var)
    # max_v = np.full((h, w), 1000000)
    for i in range(h):
        if i + 1 > k:
            var_temp = np.zeros(w)
            for j in range(w):
                if var[i, j] < 0.00001:
                    var_temp[j] = 0.00001
                else:
                    var_temp[j] = var[i, j]

            avc[i] = 1.0 / (i + 1 - k) * (np.nansum(feature[k:i + 1] * feature[0:i + 1 - k], axis=0)) / var_temp
    return avc


def skewness_res(res_f):
    res = np.copy(res_f)
    h, w = res.shape
    sn = np.full((h, w), np.nan)
    for i in range(h):
        up = math.sqrt(i + 1) * np.nansum(np.power(res[:i + 1], 3), axis=0)
        down = np.power(np.nansum(np.power(res[0:i + 1], 2), axis=0), 1.5)
        for j in range(w):
            if down[j] < 0.00001:
                down[j] = 0.0001
        sn[i] = up / down
    return sn


def kurtosis_res(res_f):
    res = np.copy(res_f)
    h, w = res.shape
    ks = np.full((h, w), np.nan)
    for i in range(h):
        up = (i + 1) * np.nansum(np.power(res[:i + 1], 4), axis=0)
        down = np.power(np.nansum(np.power(res[0:i + 1], 2), axis=0), 2)
        for j in range(w):
            if down[j] < 0.00001:
                down[j] = 0.0001
        ks[i] = up / down - 3
    return ks


def extremum_measure_sofvariation(res_f):
    res = np.copy(res_f)
    h, w = res.shape
    es = np.full((h, w), np.nan)
    for i in range(h):
        max_res = np.nanmax(res[:i + 1], axis=0)
        min_res = np.nanmin(res[:i + 1], axis=0)
        es[i] = max_res - min_res
    return es